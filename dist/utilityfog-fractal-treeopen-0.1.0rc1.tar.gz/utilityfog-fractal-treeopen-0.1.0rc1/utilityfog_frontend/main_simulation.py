def run_simulation(config):
    print("Running simulation with config:", config)
    return {"status": "success", "config_used": config}
